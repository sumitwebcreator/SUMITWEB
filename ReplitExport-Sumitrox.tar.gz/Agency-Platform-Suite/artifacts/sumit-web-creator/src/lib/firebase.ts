import { initializeApp, getApps, type FirebaseApp } from "firebase/app";
import {
  getAuth,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from "firebase/auth";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  getFirestore,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  type Firestore,
} from "firebase/firestore";
import type { ClientMessage, MessageInput, WebsiteContent } from "@/types";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY ?? "AIzaSyDobDpsLTSbNlp_kvPV4fcraxN4VXm2UoI",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ?? "sumit-web-16cd2.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID ?? "sumit-web-16cd2",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ?? "sumit-web-16cd2.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ?? "888359548071",
  appId: import.meta.env.VITE_FIREBASE_APP_ID ?? "1:888359548071:web:c674182650e57621d81782",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID ?? "G-25G8D52XW6",
};

export const adminEmail = "sumitwebcreators@gmail.com";
export const adminEmails = [
  "sumitwebcreators@gmail.com",
  "sb888284@gmail.com",
  "bhargavas382@gmail.com",
];

function isAllowedAdmin(email: string | null | undefined) {
  return !!email && adminEmails.includes(email.trim().toLowerCase());
}

export const firebaseConfigured = Object.values(firebaseConfig).every(
  (value) => typeof value === "string" && value.trim().length > 0,
);

let app: FirebaseApp | null = null;
let database: Firestore | null = null;

function getFirebaseAuthMessage(error: unknown) {
  const code = typeof error === "object" && error && "code" in error ? String(error.code) : "";
  if (code === "auth/invalid-credential" || code === "auth/wrong-password") {
    return "Firebase rejected this password for the admin account. The password must be the one saved in Firebase Authentication, not only written in website code.";
  }
  if (code === "auth/user-not-found") {
    return "The admin account has not been created in Firebase Authentication yet.";
  }
  if (code === "auth/operation-not-allowed") {
    return "Email/Password login is not enabled in Firebase Authentication. Enable it under Authentication > Sign-in method.";
  }
  if (code === "auth/too-many-requests") {
    return "Firebase temporarily blocked login attempts. Wait a few minutes or reset the password.";
  }
  if (error instanceof Error) {
    return error.message;
  }
  return "Firebase authentication failed.";
}

function requireFirebase() {
  if (!firebaseConfigured) {
    throw new Error("Firebase configuration is missing. Add the VITE_FIREBASE_* values to connect the live backend.");
  }

  if (!app) {
    app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
    database = getFirestore(app);
  }

  return {
    app,
    auth: getAuth(app),
    db: database as Firestore,
  };
}

export function subscribeWebsiteContent(
  onContent: (content: WebsiteContent | null) => void,
  onError: (message: string) => void,
) {
  const { db } = requireFirebase();
  return onSnapshot(
    doc(db, "websiteContent", "main"),
    (snapshot) => onContent(snapshot.exists() ? (snapshot.data() as WebsiteContent) : null),
    (error) => onError(error.message),
  );
}

export async function readWebsiteContent() {
  const { db } = requireFirebase();
  const snapshot = await getDoc(doc(db, "websiteContent", "main"));
  return snapshot.exists() ? (snapshot.data() as WebsiteContent) : null;
}

export async function saveWebsiteContent(content: WebsiteContent) {
  const { db } = requireFirebase();
  await setDoc(doc(db, "websiteContent", "main"), content, { merge: true });
}

export async function saveMessage(input: MessageInput) {
  const { db } = requireFirebase();
  await addDoc(collection(db, "messages"), {
    ...input,
    createdAt: serverTimestamp(),
  });
}

export function subscribeMessages(
  onMessages: (messages: ClientMessage[]) => void,
  onError: (message: string) => void,
) {
  const { db } = requireFirebase();
  return onSnapshot(
    query(collection(db, "messages"), orderBy("createdAt", "desc"), limit(100)),
    (snapshot) => {
      onMessages(
        snapshot.docs.map((entry) => {
          const data = entry.data();
          const createdAtValue = data.createdAt;
          const createdAt = createdAtValue?.toDate ? createdAtValue.toDate().toLocaleString() : "Just now";
          return {
            id: entry.id,
            name: String(data.name ?? ""),
            email: String(data.email ?? ""),
            phone: String(data.phone ?? ""),
            message: String(data.message ?? ""),
            createdAt,
          };
        }),
      );
    },
    (error) => onError(error.message),
  );
}

export async function loginAdmin(email: string, password: string) {
  const { auth } = requireFirebase();
  const normalizedEmail = email.trim().toLowerCase();

  if (!isAllowedAdmin(normalizedEmail)) {
    throw new Error(`Email is not in the admin list. Allowed: ${adminEmails.join(", ")}.`);
  }

  try {
    const credential = await signInWithEmailAndPassword(auth, normalizedEmail, password);
    if (!isAllowedAdmin(credential.user.email)) {
      await signOut(auth);
      throw new Error("This account is not allowed to access the admin panel.");
    }
    return credential.user;
  } catch (error) {
    throw new Error(getFirebaseAuthMessage(error));
  }
}

export function listenAuth(onUser: (user: User | null) => void) {
  const { auth } = requireFirebase();
  return onAuthStateChanged(auth, (user) => onUser(isAllowedAdmin(user?.email) ? user : null));
}

export async function sendAdminPasswordReset(email: string) {
  const { auth } = requireFirebase();
  const normalizedEmail = email.trim().toLowerCase();
  if (!isAllowedAdmin(normalizedEmail)) {
    throw new Error(`Email is not in the admin list. Allowed: ${adminEmails.join(", ")}.`);
  }
  try {
    await sendPasswordResetEmail(auth, normalizedEmail);
  } catch (error) {
    throw new Error(getFirebaseAuthMessage(error));
  }
}

export async function logoutAdmin() {
  const { auth } = requireFirebase();
  await signOut(auth);
}
