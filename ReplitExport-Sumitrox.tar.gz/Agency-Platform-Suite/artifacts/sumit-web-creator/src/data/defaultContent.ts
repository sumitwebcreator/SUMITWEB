import type { WebsiteContent } from "@/types";

const image = (label: string, accent: string) =>
  `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#061a36"/><stop offset="1" stop-color="${accent}"/></linearGradient><linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#f0d58c"/><stop offset="1" stop-color="#b98225"/></linearGradient></defs><rect width="1200" height="800" fill="url(#g)"/><circle cx="1040" cy="140" r="240" fill="rgba(255,255,255,.08)"/><circle cx="160" cy="680" r="250" fill="rgba(212,167,75,.16)"/><rect x="170" y="138" width="860" height="524" rx="44" fill="rgba(255,255,255,.10)" stroke="rgba(234,210,155,.36)"/><rect x="220" y="198" width="330" height="34" rx="17" fill="url(#gold)" opacity=".9"/><rect x="220" y="272" width="700" height="34" rx="17" fill="rgba(255,255,255,.68)"/><rect x="220" y="330" width="570" height="24" rx="12" fill="rgba(255,255,255,.38)"/><rect x="220" y="438" width="220" height="106" rx="24" fill="rgba(255,255,255,.14)" stroke="rgba(255,255,255,.22)"/><rect x="490" y="438" width="220" height="106" rx="24" fill="rgba(255,255,255,.14)" stroke="rgba(255,255,255,.22)"/><rect x="760" y="438" width="120" height="106" rx="24" fill="rgba(216,173,88,.62)"/><path d="M875 198c48 74 50 139 6 194-43 54-115 73-216 57 78-42 118-92 119-150 0-43 30-77 91-101Z" fill="rgba(216,173,88,.20)"/></svg>`)}`;

export const defaultContent: WebsiteContent = {
  hero: {
    title: "Premium Websites That Turn Visitors Into Customers",
    subtitle:
      "SumitWebCreator builds fast, modern, mobile-ready websites for agencies, stores, startups, and service businesses with real business strategy behind every page.",
    image: image("Luxury Web Studio", "#123764"),
  },
  services: [
    {
      id: "service-web-design",
      title: "Website Design",
      summary: "High-converting business websites with polished brand presentation.",
      details:
        "We create professional websites with clear messaging, responsive layouts, service pages, contact flows, and premium visuals so your business looks trustworthy from the first click.",
      image: image("Website Design", "#183f73"),
    },
    {
      id: "service-ecommerce",
      title: "Ecommerce Store",
      summary: "Product-focused online stores designed for smooth buying journeys.",
      details:
        "From product presentation to checkout-ready structure, we design store experiences that help customers browse confidently and contact you quickly.",
      image: image("Online Store", "#7a5a20"),
    },
    {
      id: "service-seo",
      title: "SEO Foundation",
      summary: "Search-ready structure for better visibility and stronger local reach.",
      details:
        "We organize headings, page titles, descriptions, performance basics, and content hierarchy so your website starts with a solid search foundation.",
      image: image("SEO Growth", "#0f365f"),
    },
    {
      id: "service-maintenance",
      title: "Maintenance and Upgrades",
      summary: "Ongoing improvements, content updates, and future feature expansion.",
      details:
        "Your website is built as a scalable system, so new pages, portfolio items, plan changes, and contact details can be updated without rebuilding from scratch.",
      image: image("Future Ready", "#684b18"),
    },
  ],
  portfolio: [
    {
      id: "portfolio-sumit-agency",
      name: "SUMIT AGENCY",
      slug: "sumit-agency",
      summary: "A premium digital agency demo for service businesses.",
      description:
        "A conversion-focused agency website with service storytelling, pricing clarity, portfolio proof, and strong contact actions for lead generation.",
      image: image("SUMIT AGENCY", "#173c6e"),
      tags: ["Agency", "Services", "Lead Generation"],
    },
    {
      id: "portfolio-nexa-agency",
      name: "NEXA AGENCY",
      slug: "nexa-agency",
      summary: "A sharp startup agency concept with modern project sections.",
      description:
        "A polished brand site for teams that need authority, case studies, smooth navigation, and a strong consulting presentation.",
      image: image("NEXA AGENCY", "#86611f"),
      tags: ["Startup", "Consulting", "Brand"],
    },
    {
      id: "portfolio-techflow",
      name: "TECHFLOW",
      slug: "techflow",
      summary: "A technology services demo with productized plans.",
      description:
        "A structured technology business website that explains complex services clearly while keeping the user path focused on booking and contact.",
      image: image("TECHFLOW", "#0a3158"),
      tags: ["Technology", "SaaS", "Automation"],
    },
    {
      id: "portfolio-urban-store",
      name: "URBAN STORE",
      slug: "urban-store",
      summary: "A clean online store concept for modern retail brands.",
      description:
        "A retail storefront demo with product highlights, category storytelling, trust signals, and direct contact actions for assisted sales.",
      image: image("URBAN STORE", "#735018"),
      tags: ["Ecommerce", "Retail", "Products"],
    },
  ],
  pricing: [
    {
      id: "pricing-basic",
      name: "Basic",
      price: "₹9,999",
      features: ["One-page business website", "Mobile responsive design", "Contact section", "WhatsApp, call, and email buttons", "Basic SEO setup"],
    },
    {
      id: "pricing-standard",
      name: "Standard",
      price: "₹24,999",
      features: ["Multi-page professional website", "Services and portfolio sections", "Contact form setup", "CMS-ready content structure", "Performance optimization"],
    },
    {
      id: "pricing-premium",
      name: "Premium",
      price: "₹49,999",
      features: ["Advanced agency platform", "Admin content editing", "Portfolio demo system", "Real-time Firebase updates", "Future upgrade foundation"],
    },
  ],
  contact: {
    phone: "9238758606",
    email: "sumitwebcreators@gmail.com",
    whatsapp: "https://wa.me/919238758606",
    address: "Available for clients across India",
    social: {
      facebook: "",
      instagram: "",
      twitter: "",
      linkedin: "",
      youtube: "",
      telegram: "",
    },
  },
  customBlocks: [],
  theme: {
    primary: "#061a36",
    accent: "#d8ad58",
    background: "#fbf8f0",
  },
};
