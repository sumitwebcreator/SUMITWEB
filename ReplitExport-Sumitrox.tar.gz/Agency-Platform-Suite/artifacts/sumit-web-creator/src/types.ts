export type HeroContent = {
  title: string;
  subtitle: string;
  image: string;
};

export type ServiceItem = {
  id: string;
  title: string;
  summary: string;
  details: string;
  image: string;
};

export type PortfolioItem = {
  id: string;
  name: string;
  slug: string;
  summary: string;
  description: string;
  image: string;
  tags: string[];
};

export type PricingItem = {
  id: string;
  name: string;
  price: string;
  features: string[];
};

export type SocialLinks = {
  facebook?: string;
  instagram?: string;
  twitter?: string;
  linkedin?: string;
  youtube?: string;
  telegram?: string;
};

export type ContactInfo = {
  phone: string;
  email: string;
  whatsapp: string;
  address: string;
  social?: SocialLinks;
};

export type CustomBlock = {
  id: string;
  title: string;
  text: string;
  image: string;
};

export type ThemeSettings = {
  primary: string;
  accent: string;
  background: string;
};

export type WebsiteContent = {
  hero: HeroContent;
  services: ServiceItem[];
  portfolio: PortfolioItem[];
  pricing: PricingItem[];
  contact: ContactInfo;
  customBlocks?: CustomBlock[];
  theme?: ThemeSettings;
};

export type ClientMessage = {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  createdAt?: string;
};

export type MessageInput = Omit<ClientMessage, "id" | "createdAt">;
