import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import { Link, Route, Router as WouterRouter, Switch, useRoute } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Bot,
  BriefcaseBusiness,
  Check,
  ChevronRight,
  Download,
  Facebook,
  ImagePlus,
  Instagram,
  Linkedin,
  LogOut,
  Mail,
  Menu,
  MessageCircle,
  Palette,
  Phone,
  Plus,
  Save,
  Send,
  Shield,
  Sparkles,
  Trash2,
  Twitter,
  X,
  Youtube,
} from "lucide-react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { defaultContent } from "@/data/defaultContent";
import {
  adminEmail,
  adminEmails,
  firebaseConfigured,
  listenAuth,
  loginAdmin,
  logoutAdmin,
  sendAdminPasswordReset,
  saveMessage,
  saveWebsiteContent,
  subscribeMessages,
  subscribeWebsiteContent,
} from "@/lib/firebase";
import type { ClientMessage, CustomBlock, MessageInput, PortfolioItem, PricingItem, ServiceItem, SocialLinks, ThemeSettings, WebsiteContent } from "@/types";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();
const navItems = ["services", "portfolio", "pricing", "contact"];

function useWebsiteContent() {
  const [content, setContent] = useState<WebsiteContent>(defaultContent);
  const [loading, setLoading] = useState(firebaseConfigured);
  const [error, setError] = useState("");
  const [usingFallback, setUsingFallback] = useState(!firebaseConfigured);

  useEffect(() => {
    if (!firebaseConfigured) {
      setLoading(false);
      setUsingFallback(true);
      return;
    }

    const unsubscribe = subscribeWebsiteContent(
      (incoming) => {
        setContent(incoming ?? defaultContent);
        setUsingFallback(!incoming);
        setLoading(false);
      },
      (message) => {
        setError(message);
        setLoading(false);
      },
    );

    return unsubscribe;
  }, []);

  return { content, loading, error, usingFallback };
}

function setMeta(title: string, description: string) {
  document.title = title;
  const meta = document.querySelector('meta[name="description"]') ?? document.createElement("meta");
  meta.setAttribute("name", "description");
  meta.setAttribute("content", description);
  document.head.appendChild(meta);
}

function ConfigBanner({ usingFallback, error }: { usingFallback: boolean; error?: string }) {
  if (firebaseConfigured && !usingFallback && !error) return null;

  return (
    <div className="config-banner">
      <strong>Firebase setup required</strong>
      <span>Add your Firebase web app config values to enable live Firestore editing and admin login.</span>
      {error ? <span> Current error: {error}</span> : null}
    </div>
  );
}

function Navbar({ contact }: { contact: WebsiteContent["contact"] }) {
  const [open, setOpen] = useState(false);

  const scrollTo = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <header className="site-nav">
      <Link href="/" className="brand-mark" aria-label="SumitWebCreator home">
        <span>SWC</span>
        <div>
          <strong>SumitWebCreator</strong>
          <small>Agency Platform</small>
        </div>
      </Link>
      <button className="menu-button" onClick={() => setOpen((value) => !value)} aria-label="Toggle navigation">
        {open ? <X size={22} /> : <Menu size={22} />}
      </button>
      <nav className={open ? "nav-links open" : "nav-links"}>
        {navItems.map((item) => (
          <button key={item} onClick={() => scrollTo(item)}>
            {item}
          </button>
        ))}
        <a href={`tel:${contact.phone}`} className="nav-action">Call now</a>
        <Link href="/admin" className="nav-admin">Admin</Link>
      </nav>
    </header>
  );
}

function Hero({ content }: { content: WebsiteContent }) {
  return (
    <section className="hero-section" id="home">
      <motion.div className="hero-copy" initial={{ opacity: 0, y: 26 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <p className="eyebrow"><Sparkles size={16} /> Professional web creation agency</p>
        <h1>{content.hero.title}</h1>
        <p className="hero-subtitle">{content.hero.subtitle}</p>
        <div className="hero-actions">
          <a href={content.contact.whatsapp} target="_blank" rel="noreferrer" className="primary-button">Start on WhatsApp</a>
          <a href={`mailto:${content.contact.email}`} className="secondary-button">Request quote</a>
        </div>
        <div className="proof-row">
          <span>Real-time CMS</span>
          <span>Firebase-ready</span>
          <span>Mobile-perfect</span>
        </div>
      </motion.div>
      <motion.div className="hero-visual" initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, delay: 0.1 }}>
        <img src={content.hero.image} alt="SumitWebCreator hero" />
        <div className="floating-card top-card">
          <strong>Live Editing</strong>
          <span>Admin changes publish instantly</span>
        </div>
        <div className="floating-card bottom-card">
          <strong>Premium Build</strong>
          <span>Designed for future upgrades</span>
        </div>
      </motion.div>
    </section>
  );
}

function Services({ services }: { services: ServiceItem[] }) {
  const [active, setActive] = useState(services[0]?.id ?? "");
  const activeService = services.find((service) => service.id === active) ?? services[0];

  useEffect(() => {
    if (services.length && !services.some((service) => service.id === active)) {
      setActive(services[0].id);
    }
  }, [services, active]);

  return (
    <section className="section" id="services">
      <div className="section-heading">
        <p className="eyebrow">Services</p>
        <h2>Everything a growing business website needs</h2>
        <p>Each service is editable from the admin dashboard and updates live across the public website.</p>
      </div>
      <div className="service-grid">
        {services.map((service, index) => (
          <motion.button
            className={service.id === active ? "service-card active" : "service-card"}
            key={service.id}
            onClick={() => setActive(service.id)}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.05 }}
          >
            <img src={service.image} alt={service.title} />
            <strong>{service.title}</strong>
            <span>{service.summary}</span>
            <small>Learn more <ChevronRight size={14} /></small>
          </motion.button>
        ))}
      </div>
      {activeService ? (
        <div className="service-detail">
          <div>
            <p className="eyebrow">Learn More</p>
            <h3>{activeService.title}</h3>
            <p>{activeService.details}</p>
          </div>
          <img src={activeService.image} alt={`${activeService.title} detail`} />
        </div>
      ) : null}
    </section>
  );
}

function Portfolio({ portfolio }: { portfolio: PortfolioItem[] }) {
  return (
    <section className="section navy-section" id="portfolio">
      <div className="section-heading light">
        <p className="eyebrow">Portfolio</p>
        <h2>Demo systems ready to show clients</h2>
        <p>Each project includes a full demo page and a detailed case-study page.</p>
      </div>
      <div className="portfolio-grid">
        {portfolio.map((project) => (
          <article className="portfolio-card" key={project.id}>
            <img src={project.image} alt={project.name} />
            <div>
              <div className="tag-row">{project.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
              <h3>{project.name}</h3>
              <p>{project.summary}</p>
              <div className="card-actions">
                <Link href={`/demo/${project.slug}`} className="gold-button">Live Demo</Link>
                <Link href={`/project/${project.slug}`} className="ghost-button">View Project</Link>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function Pricing({ pricing }: { pricing: PricingItem[] }) {
  return (
    <section className="section" id="pricing">
      <div className="section-heading">
        <p className="eyebrow">Pricing</p>
        <h2>Transparent plans that can be edited anytime</h2>
        <p>Admin changes to prices and features publish instantly through Firestore.</p>
      </div>
      <div className="pricing-grid">
        {pricing.map((plan, index) => (
          <motion.article className={index === 1 ? "pricing-card featured" : "pricing-card"} key={plan.id} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <span className="plan-label">{plan.name}</span>
            <h3>{plan.price}</h3>
            <ul>
              {plan.features.map((feature) => (
                <li key={feature}><Check size={17} /> {feature}</li>
              ))}
            </ul>
            <a href="https://wa.me/919238758606" target="_blank" rel="noreferrer" className="primary-button full">Choose {plan.name}</a>
          </motion.article>
        ))}
      </div>
    </section>
  );
}

function Contact({ contact }: { contact: WebsiteContent["contact"] }) {
  const { toast } = useToast();
  const [form, setForm] = useState<MessageInput>({ name: "", email: "", phone: "", message: "" });
  const [saving, setSaving] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSaving(true);
    try {
      await saveMessage(form);
      setForm({ name: "", email: "", phone: "", message: "" });
      toast({ title: "Message saved", description: "The enquiry was stored in Firebase messages." });
    } catch (error) {
      toast({ title: "Firebase setup needed", description: error instanceof Error ? error.message : "Unable to save the message." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="section contact-section" id="contact">
      <div className="contact-panel">
        <div>
          <p className="eyebrow">Contact</p>
          <h2>Ready to build a premium website?</h2>
          <p>Reach SumitWebCreator directly or submit the form. When Firebase is configured, every form entry is stored in Firestore and visible in admin.</p>
          <div className="contact-actions">
            <a href={contact.whatsapp} target="_blank" rel="noreferrer"><MessageCircle size={18} /> WhatsApp</a>
            <a href={`tel:${contact.phone}`}><Phone size={18} /> {contact.phone}</a>
            <a href={`mailto:${contact.email}`}><Mail size={18} /> {contact.email}</a>
          </div>
          <SocialRow social={contact.social} />
        </div>
        <form onSubmit={submit} className="contact-form">
          <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="Your name" required />
          <input value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} placeholder="Email address" type="email" required />
          <input value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} placeholder="Phone number" required />
          <textarea value={form.message} onChange={(event) => setForm({ ...form, message: event.target.value })} placeholder="Tell us what you want to build" required />
          <button type="submit" className="primary-button" disabled={saving}>{saving ? "Saving..." : "Send message"}</button>
        </form>
      </div>
    </section>
  );
}

function buildAiContext(content: WebsiteContent) {
  const parts = [
    `Hero: ${content.hero.title} - ${content.hero.subtitle}`,
    `Services: ${content.services.map((service) => `${service.title} (${service.summary})`).join("; ")}`,
    `Portfolio: ${content.portfolio.map((project) => `${project.name} - ${project.summary}`).join("; ")}`,
    `Pricing: ${content.pricing.map((plan) => `${plan.name} ${plan.price}: ${plan.features.join(", ")}`).join("; ")}`,
    `Contact: phone ${content.contact.phone}, email ${content.contact.email}, whatsapp ${content.contact.whatsapp}, address ${content.contact.address}`,
  ];
  if (content.customBlocks?.length) {
    parts.push(`Custom Sections: ${content.customBlocks.map((block) => `${block.title} - ${block.text}`).join("; ")}`);
  }
  if (content.contact.social) {
    const socials = Object.entries(content.contact.social).filter(([, value]) => value).map(([key, value]) => `${key}: ${value}`);
    if (socials.length) parts.push(`Social: ${socials.join("; ")}`);
  }
  return parts.join("\n");
}

function Chatbot({ content }: { content: WebsiteContent }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([{ from: "bot", text: "Ask me anything. I can answer using AI and the live website information." }]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);

  const send = async (question = input) => {
    const trimmed = question.trim();
    if (!trimmed || thinking) return;
    setMessages((items) => [...items, { from: "user", text: trimmed }]);
    setInput("");
    setThinking(true);
    try {
      const response = await fetch("/api/ai/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: trimmed, context: buildAiContext(content) }),
      });
      const data = await response.json();
      const text = response.ok ? String(data.answer ?? "No answer.") : `AI error: ${data.error ?? "request failed"}`;
      setMessages((items) => [...items, { from: "bot", text }]);
    } catch (error) {
      setMessages((items) => [...items, { from: "bot", text: error instanceof Error ? error.message : "AI request failed." }]);
    } finally {
      setThinking(false);
    }
  };

  return (
    <div className="chatbot">
      {open ? (
        <div className="chat-window">
          <div className="chat-head">
            <div><Bot size={18} /> AI Assistant</div>
            <button onClick={() => setOpen(false)} aria-label="Close chatbot"><X size={18} /></button>
          </div>
          <div className="chat-messages">
            {messages.map((message, index) => <p className={message.from === "bot" ? "bot-message" : "user-message"} key={`${index}-${message.text.slice(0, 12)}`}>{message.text}</p>)}
            {thinking ? <p className="bot-message thinking">Thinking...</p> : null}
          </div>
          <div className="quick-replies">
            {["Suggest best plan", "Show pricing", "Contact details", "Build my website"].map((item) => <button key={item} onClick={() => send(item)} disabled={thinking}>{item}</button>)}
          </div>
          <form onSubmit={(event) => { event.preventDefault(); send(); }} className="chat-input">
            <input value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ask anything" disabled={thinking} />
            <button type="submit" disabled={thinking}><Send size={17} /></button>
          </form>
        </div>
      ) : null}
      <button className="chat-toggle" onClick={() => setOpen((value) => !value)}><Bot size={22} /> AI Assistant</button>
    </div>
  );
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function renderStandaloneHtml(content: WebsiteContent): string {
  const theme = content.theme ?? { primary: "#061a36", accent: "#d8ad58", background: "#fbf8f0" };
  const social = content.contact.social ?? {};
  const socialEntries = Object.entries(social).filter(([, value]) => value);
  const heroTitle = escapeHtml(content.hero.title);
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${heroTitle} | SumitWebCreator</title>
<meta name="description" content="${escapeHtml(content.hero.subtitle)}" />
<style>
  :root { --primary: ${theme.primary}; --accent: ${theme.accent}; --bg: ${theme.background}; }
  * { box-sizing: border-box; }
  body { margin: 0; font-family: 'Inter', system-ui, -apple-system, sans-serif; color: #061a36; background: var(--bg); line-height: 1.55; }
  .nav { display: flex; justify-content: space-between; align-items: center; padding: 18px 6vw; background: var(--primary); color: #fff; position: sticky; top: 0; z-index: 50; }
  .nav strong { color: var(--accent); letter-spacing: 1px; }
  .nav a { color: #fff; margin-left: 18px; text-decoration: none; font-size: 14px; }
  .hero { background: var(--primary); color: #fff; padding: 90px 6vw; display: grid; grid-template-columns: 1.2fr 1fr; gap: 40px; align-items: center; }
  .hero h1 { font-size: clamp(32px, 5vw, 56px); margin: 0 0 18px; }
  .hero p { color: #d6dae3; margin: 0 0 24px; max-width: 540px; }
  .hero img { width: 100%; border-radius: 22px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
  .btn { display: inline-block; padding: 14px 26px; background: var(--accent); color: var(--primary); border-radius: 999px; text-decoration: none; font-weight: 600; }
  .section { padding: 80px 6vw; }
  .section h2 { font-size: clamp(28px, 4vw, 42px); margin: 0 0 12px; color: var(--primary); }
  .eyebrow { color: var(--accent); font-weight: 600; text-transform: uppercase; letter-spacing: 2px; font-size: 12px; margin: 0 0 8px; }
  .grid { display: grid; gap: 22px; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); margin-top: 32px; }
  .card { background: #fff; border-radius: 22px; overflow: hidden; box-shadow: 0 12px 40px rgba(6,26,54,0.08); }
  .card img { width: 100%; height: 200px; object-fit: cover; }
  .card-body { padding: 22px; }
  .card-body h3 { margin: 0 0 8px; color: var(--primary); }
  .price { color: var(--accent); font-size: 28px; font-weight: 700; margin: 8px 0; }
  .features { list-style: none; padding: 0; margin: 0; }
  .features li { padding: 6px 0; border-bottom: 1px solid #eee; }
  .contact { background: var(--primary); color: #fff; padding: 80px 6vw; }
  .contact h2 { color: #fff; }
  .contact a { color: var(--accent); text-decoration: none; display: block; margin: 8px 0; font-weight: 600; }
  .footer { background: #04142a; color: #d6dae3; padding: 30px 6vw; text-align: center; font-size: 13px; }
  .footer a { color: var(--accent); margin: 0 8px; text-decoration: none; }
  @media (max-width: 760px) { .hero { grid-template-columns: 1fr; } .nav a { margin-left: 12px; font-size: 13px; } }
</style>
</head>
<body>
<nav class="nav">
  <strong>SUMITWEBCREATOR</strong>
  <div>
    <a href="#services">Services</a>
    <a href="#portfolio">Portfolio</a>
    <a href="#pricing">Pricing</a>
    <a href="#contact">Contact</a>
  </div>
</nav>
<header class="hero">
  <div>
    <p class="eyebrow">Premium Website Agency</p>
    <h1>${heroTitle}</h1>
    <p>${escapeHtml(content.hero.subtitle)}</p>
    <a class="btn" href="#contact">Start your project</a>
  </div>
  <img src="${escapeHtml(content.hero.image)}" alt="Hero" />
</header>
<section class="section" id="services">
  <p class="eyebrow">Services</p>
  <h2>What we build</h2>
  <div class="grid">
    ${content.services.map((service) => `
      <article class="card">
        <img src="${escapeHtml(service.image)}" alt="${escapeHtml(service.title)}" />
        <div class="card-body"><h3>${escapeHtml(service.title)}</h3><p>${escapeHtml(service.summary)}</p><p>${escapeHtml(service.details)}</p></div>
      </article>
    `).join("")}
  </div>
</section>
<section class="section" id="portfolio" style="background:#fff">
  <p class="eyebrow">Portfolio</p>
  <h2>Live demos</h2>
  <div class="grid">
    ${content.portfolio.map((project) => `
      <article class="card">
        <img src="${escapeHtml(project.image)}" alt="${escapeHtml(project.name)}" />
        <div class="card-body"><h3>${escapeHtml(project.name)}</h3><p>${escapeHtml(project.summary)}</p><p style="color:var(--accent);font-size:12px;text-transform:uppercase;letter-spacing:1px">${project.tags.map((tag) => escapeHtml(tag)).join(" • ")}</p></div>
      </article>
    `).join("")}
  </div>
</section>
<section class="section" id="pricing">
  <p class="eyebrow">Pricing</p>
  <h2>Plans for every stage</h2>
  <div class="grid">
    ${content.pricing.map((plan) => `
      <article class="card"><div class="card-body"><h3>${escapeHtml(plan.name)}</h3><div class="price">${escapeHtml(plan.price)}</div><ul class="features">${plan.features.map((feature) => `<li>${escapeHtml(feature)}</li>`).join("")}</ul></div></article>
    `).join("")}
  </div>
</section>
${(content.customBlocks ?? []).length ? `
<section class="section" id="extras" style="background:#fff">
  <p class="eyebrow">More</p>
  <h2>Additional sections</h2>
  <div class="grid">
    ${(content.customBlocks ?? []).map((block) => `
      <article class="card">${block.image ? `<img src="${escapeHtml(block.image)}" alt="${escapeHtml(block.title)}" />` : ""}<div class="card-body"><h3>${escapeHtml(block.title)}</h3><p>${escapeHtml(block.text)}</p></div></article>
    `).join("")}
  </div>
</section>` : ""}
<section class="contact" id="contact">
  <p class="eyebrow">Contact</p>
  <h2>Let us build your website</h2>
  <a href="tel:${escapeHtml(content.contact.phone)}">Call ${escapeHtml(content.contact.phone)}</a>
  <a href="mailto:${escapeHtml(content.contact.email)}">Email ${escapeHtml(content.contact.email)}</a>
  <a href="${escapeHtml(content.contact.whatsapp)}" target="_blank" rel="noreferrer">WhatsApp</a>
  <p>${escapeHtml(content.contact.address)}</p>
</section>
<footer class="footer">
  <div>${socialEntries.map(([key, value]) => `<a href="${escapeHtml(String(value))}" target="_blank" rel="noreferrer">${escapeHtml(key.charAt(0).toUpperCase() + key.slice(1))}</a>`).join("")}</div>
  <p>© ${new Date().getFullYear()} SumitWebCreator. All rights reserved.</p>
</footer>
</body>
</html>`;
}

function applyTheme(theme: ThemeSettings | undefined) {
  if (!theme) return;
  const root = document.documentElement;
  root.style.setProperty("--theme-primary", theme.primary);
  root.style.setProperty("--theme-accent", theme.accent);
  root.style.setProperty("--theme-background", theme.background);
}

const socialIcons: Record<keyof SocialLinks, typeof Facebook> = {
  facebook: Facebook,
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  youtube: Youtube,
  telegram: Send,
};

function SocialRow({ social, variant = "light" }: { social?: SocialLinks; variant?: "light" | "dark" }) {
  if (!social) return null;
  const entries = (Object.entries(social) as Array<[keyof SocialLinks, string | undefined]>).filter(([, value]) => value);
  if (!entries.length) return null;
  return (
    <div className={`social-row ${variant}`}>
      {entries.map(([key, value]) => {
        const Icon = socialIcons[key];
        return (
          <a key={key} href={value} target="_blank" rel="noreferrer" aria-label={key}>
            <Icon size={18} />
          </a>
        );
      })}
    </div>
  );
}

function CustomBlocks({ blocks }: { blocks?: CustomBlock[] }) {
  if (!blocks || blocks.length === 0) return null;
  return (
    <section className="section custom-blocks-section" id="extras">
      <div className="section-heading">
        <p className="eyebrow">More</p>
        <h2>Additional sections</h2>
        <p>Custom content added by the admin team.</p>
      </div>
      <div className="custom-blocks-grid">
        {blocks.map((block) => (
          <article className="custom-block" key={block.id}>
            {block.image ? <img src={block.image} alt={block.title} /> : null}
            <div>
              <h3>{block.title}</h3>
              <p>{block.text}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function HomePage() {
  const { content, loading, error, usingFallback } = useWebsiteContent();

  useEffect(() => {
    setMeta("SumitWebCreator | Professional Website Creation Agency", "Premium agency platform with Firebase-powered real-time website editing, admin control, portfolio demos, pricing, and contact system.");
  }, []);

  useEffect(() => { applyTheme(content.theme); }, [content.theme]);

  if (loading) return <div className="loading-screen">Loading live website content...</div>;

  return (
    <main>
      <Navbar contact={content.contact} />
      <Hero content={content} />
      <Services services={content.services} />
      <Portfolio portfolio={content.portfolio} />
      <Pricing pricing={content.pricing} />
      <CustomBlocks blocks={content.customBlocks} />
      <Contact contact={content.contact} />
      <Footer contact={content.contact} />
      <Chatbot content={content} />
    </main>
  );
}

function Footer({ contact }: { contact: WebsiteContent["contact"] }) {
  return (
    <footer className="footer">
      <div>
        <strong>SumitWebCreator</strong>
        <p>Professional websites, admin systems, real-time editing, and scalable digital platforms.</p>
        <SocialRow social={contact.social} variant="dark" />
      </div>
      <div>
        <a href={contact.whatsapp} target="_blank" rel="noreferrer">WhatsApp</a>
        <a href={`tel:${contact.phone}`}>Call</a>
        <a href={`mailto:${contact.email}`}>Email</a>
      </div>
    </footer>
  );
}

function DemoPage() {
  const { content } = useWebsiteContent();
  const [, params] = useRoute("/demo/:slug");
  const project = content.portfolio.find((item) => item.slug === params?.slug);

  useEffect(() => {
    setMeta(`${project?.name ?? "Demo"} | SumitWebCreator Demo`, "A portfolio demo page built inside the SumitWebCreator platform.");
  }, [project]);

  if (!project) return <NotFound />;

  return (
    <main className="demo-page">
      <Navbar contact={content.contact} />
      <section className="demo-hero" style={{ backgroundImage: `linear-gradient(100deg, rgba(6,26,54,.94), rgba(6,26,54,.74)), url("${project.image}")` }}>
        <Link href="/" className="back-link"><ArrowLeft size={17} /> Back to website</Link>
        <p className="eyebrow">Live Demo</p>
        <h1>{project.name}</h1>
        <p>{project.description}</p>
        <a href={content.contact.whatsapp} target="_blank" rel="noreferrer" className="gold-button">Build a similar website</a>
      </section>
      <section className="demo-content">
        <div className="demo-block large">
          <BriefcaseBusiness />
          <h2>Business-ready presentation</h2>
          <p>This demo shows a complete multi-section website experience with clear messaging, service proof, conversion actions, and a polished mobile layout.</p>
        </div>
        <div className="demo-block">
          <h3>Landing experience</h3>
          <p>Strong first screen, offer clarity, service highlights, and direct action buttons.</p>
        </div>
        <div className="demo-block">
          <h3>Trust system</h3>
          <p>Portfolio proof, benefits, process explanation, and client enquiry flow.</p>
        </div>
        <div className="demo-block">
          <h3>Growth foundation</h3>
          <p>Built to add pages, CMS editing, analytics, automation, and future integrations.</p>
        </div>
      </section>
    </main>
  );
}

function ProjectPage() {
  const { content } = useWebsiteContent();
  const [, params] = useRoute("/project/:slug");
  const project = content.portfolio.find((item) => item.slug === params?.slug);

  useEffect(() => {
    setMeta(`${project?.name ?? "Project"} | SumitWebCreator`, "A detailed SumitWebCreator portfolio project page.");
  }, [project]);

  if (!project) return <NotFound />;

  return (
    <main>
      <Navbar contact={content.contact} />
      <section className="project-detail">
        <Link href="/" className="back-link dark"><ArrowLeft size={17} /> Back to website</Link>
        <div className="project-detail-grid">
          <div>
            <p className="eyebrow">Project Detail</p>
            <h1>{project.name}</h1>
            <p>{project.description}</p>
            <div className="tag-row dark-tags">{project.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
            <div className="hero-actions">
              <Link href={`/demo/${project.slug}`} className="primary-button">Open live demo</Link>
              <a href={content.contact.whatsapp} target="_blank" rel="noreferrer" className="secondary-button">Discuss this style</a>
            </div>
          </div>
          <img src={project.image} alt={project.name} />
        </div>
      </section>
    </main>
  );
}

function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Unable to read image file."));
    reader.readAsDataURL(file);
  });
}

function TextField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="field-label">
      <span>{label}</span>
      <input value={value} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
}

function TextAreaField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="field-label">
      <span>{label}</span>
      <textarea value={value} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
}

function ImagePicker({ label, image, onImage }: { label: string; image: string; onImage: (value: string) => void }) {
  const pick = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) onImage(await fileToDataUrl(file));
  };

  return (
    <label className="image-picker">
      <img src={image} alt={label} />
      <span><ImagePlus size={17} /> {label}</span>
      <input type="file" accept="image/*" onChange={pick} />
    </label>
  );
}

function AdminPage() {
  const { content, error, usingFallback } = useWebsiteContent();
  const { toast } = useToast();
  const [userReady, setUserReady] = useState(!firebaseConfigured);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [login, setLogin] = useState({ email: adminEmail, password: "" });
  const [loginError, setLoginError] = useState("");
  const [resettingPassword, setResettingPassword] = useState(false);
  const [draft, setDraft] = useState<WebsiteContent>(content);
  const [saving, setSaving] = useState(false);
  const [messages, setMessages] = useState<ClientMessage[]>([]);
  const [messageError, setMessageError] = useState("");

  useEffect(() => {
    setMeta("Admin Panel | SumitWebCreator", "Single-admin Firebase dashboard for editing SumitWebCreator live website content.");
  }, []);

  useEffect(() => setDraft(content), [content]);

  useEffect(() => {
    if (!firebaseConfigured) return;
    const unsubscribe = listenAuth((user) => {
      setUserEmail(user?.email ?? null);
      setUserReady(true);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!firebaseConfigured || !userEmail) return;
    return subscribeMessages(setMessages, setMessageError);
  }, [userEmail]);

  const signIn = async (event: FormEvent) => {
    event.preventDefault();
    setLoginError("");
    try {
      const user = await loginAdmin(login.email, login.password);
      setUserEmail(user.email ?? null);
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : "Login failed.");
    }
  };

  const resetPassword = async () => {
    setLoginError("");
    setResettingPassword(true);
    try {
      await sendAdminPasswordReset(login.email);
      toast({ title: "Reset email sent", description: `Check ${adminEmail} for the Firebase password reset link.` });
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : "Unable to send password reset email.");
    } finally {
      setResettingPassword(false);
    }
  };

  const seedDefaultContent = async () => {
    setSaving(true);
    try {
      await saveWebsiteContent(defaultContent);
      setDraft(defaultContent);
      toast({ title: "Default content published", description: "Firestore websiteContent/main now has the full starter website content." });
    } catch (error) {
      toast({ title: "Unable to publish default content", description: error instanceof Error ? error.message : "Firebase save failed." });
    } finally {
      setSaving(false);
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      await saveWebsiteContent(draft);
      toast({ title: "Website updated", description: "Live website content was saved to Firestore." });
    } catch (error) {
      toast({ title: "Unable to save", description: error instanceof Error ? error.message : "Firebase save failed." });
    } finally {
      setSaving(false);
    }
  };

  const updateService = (id: string, updater: (service: ServiceItem) => ServiceItem) => setDraft({ ...draft, services: draft.services.map((service) => service.id === id ? updater(service) : service) });
  const updateProject = (id: string, updater: (project: PortfolioItem) => PortfolioItem) => setDraft({ ...draft, portfolio: draft.portfolio.map((project) => project.id === id ? updater(project) : project) });
  const updatePlan = (id: string, updater: (plan: PricingItem) => PricingItem) => setDraft({ ...draft, pricing: draft.pricing.map((plan) => plan.id === id ? updater(plan) : plan) });

  const addService = () => setDraft({ ...draft, services: [...draft.services, { id: `service-${Date.now()}`, title: "New Service", summary: "Short service summary", details: "Detailed explanation", image: defaultContent.hero.image }] });
  const addProject = () => setDraft({ ...draft, portfolio: [...draft.portfolio, { id: `portfolio-${Date.now()}`, name: "NEW PROJECT", slug: `new-project-${Date.now()}`, summary: "Project summary", description: "Project description", image: defaultContent.hero.image, tags: ["Website"] }] });
  const addPlan = () => setDraft({ ...draft, pricing: [...draft.pricing, { id: `pricing-${Date.now()}`, name: "New Plan", price: "₹0", features: ["Feature one"] }] });

  function moveItem<T>(list: T[], index: number, direction: -1 | 1): T[] {
    const target = index + direction;
    if (target < 0 || target >= list.length) return list;
    const next = [...list];
    [next[index], next[target]] = [next[target], next[index]];
    return next;
  }
  const reorderService = (index: number, direction: -1 | 1) => setDraft({ ...draft, services: moveItem(draft.services, index, direction) });
  const reorderProject = (index: number, direction: -1 | 1) => setDraft({ ...draft, portfolio: moveItem(draft.portfolio, index, direction) });
  const reorderPlan = (index: number, direction: -1 | 1) => setDraft({ ...draft, pricing: moveItem(draft.pricing, index, direction) });
  const removeService = (id: string) => setDraft({ ...draft, services: draft.services.filter((service) => service.id !== id) });
  const removeProject = (id: string) => setDraft({ ...draft, portfolio: draft.portfolio.filter((project) => project.id !== id) });
  const removePlan = (id: string) => setDraft({ ...draft, pricing: draft.pricing.filter((plan) => plan.id !== id) });

  const updateSocial = (key: keyof SocialLinks, value: string) => setDraft({ ...draft, contact: { ...draft.contact, social: { ...(draft.contact.social ?? {}), [key]: value } } });
  const updateTheme = (patch: Partial<ThemeSettings>) => setDraft({ ...draft, theme: { ...(draft.theme ?? defaultContent.theme!), ...patch } });

  const updateBlock = (id: string, updater: (block: CustomBlock) => CustomBlock) => setDraft({ ...draft, customBlocks: (draft.customBlocks ?? []).map((block) => block.id === id ? updater(block) : block) });
  const addBlock = () => setDraft({ ...draft, customBlocks: [...(draft.customBlocks ?? []), { id: `block-${Date.now()}`, title: "New section", text: "Describe this section.", image: "" }] });
  const removeBlock = (id: string) => setDraft({ ...draft, customBlocks: (draft.customBlocks ?? []).filter((block) => block.id !== id) });
  const reorderBlock = (index: number, direction: -1 | 1) => setDraft({ ...draft, customBlocks: moveItem(draft.customBlocks ?? [], index, direction) });

  const downloadSingleFile = () => {
    const html = renderStandaloneHtml(draft);
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "sumitweb.html";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    toast({ title: "Single-file site ready", description: "sumitweb.html has been downloaded." });
  };

  if (!firebaseConfigured) {
    return (
      <main className="admin-shell">
        <ConfigBanner usingFallback={usingFallback} error={error} />
        <section className="admin-login setup-card">
          <Shield size={38} />
          <h1>Firebase backend is required</h1>
          <p>This admin panel is built for Firebase Authentication and Firestore. Add the VITE_FIREBASE_* values, create the single admin account in Firebase Authentication, and the dashboard will unlock real-time editing.</p>
          <div className="setup-list">
            <span>Allowed admin emails: {adminEmails.join(", ")}</span>
            <span>Firestore collection: websiteContent</span>
            <span>Document: websiteContent/main</span>
            <span>Messages collection: messages</span>
          </div>
          <Link href="/" className="primary-button">View public website preview</Link>
        </section>
      </main>
    );
  }

  if (!userReady) return <div className="loading-screen">Checking admin access...</div>;

  if (!userEmail) {
    return (
      <main className="admin-shell login-bg">
        <form className="admin-login" onSubmit={signIn}>
          <Shield size={38} />
          <p className="eyebrow">Multi-Admin Access</p>
          <h1>SumitWebCreator Admin</h1>
          <p>Up to 5 admin sessions. Allowed accounts:<br />{adminEmails.join(", ")}.</p>
          <input type="email" value={login.email} onChange={(event) => setLogin({ ...login, email: event.target.value })} placeholder="Admin email" autoComplete="username" required />
          <input type="password" value={login.password} onChange={(event) => setLogin({ ...login, password: event.target.value })} placeholder="Password" autoComplete="current-password" required />
          {loginError ? <span className="form-error">{loginError}</span> : null}
          <button className="primary-button full" type="submit">Login to dashboard</button>
          <button className="reset-password-button" type="button" onClick={resetPassword} disabled={resettingPassword}>{resettingPassword ? "Sending reset link..." : "Send password reset link"}</button>
          <div className="login-help-box">
            <strong>Firebase setup checklist</strong>
            <span>1. Firebase Authentication must have Email/Password enabled.</span>
            <span>2. Create users in Firebase: {adminEmails.join(", ")}</span>
            <span>3. Set each user password in Firebase Console. The app cannot create the password just by putting it in code.</span>
            <span>4. After login, click publish default content if the websiteContent/main document is empty.</span>
          </div>
          <Link href="/" className="back-link dark">Back to website</Link>
        </form>
      </main>
    );
  }

  return (
    <main className="admin-dashboard">
      <aside className="admin-sidebar">
        <Link href="/" className="brand-mark">
          <span>SWC</span>
          <div><strong>Admin Panel</strong><small>{userEmail}</small></div>
        </Link>
        {[
          ["hero-editor", "Hero Editor"],
          ["services-editor", "Services Editor"],
          ["portfolio-editor", "Portfolio Editor"],
          ["pricing-editor", "Pricing Editor"],
          ["custom-blocks-editor", "Custom Sections"],
          ["contact-editor", "Contact Info"],
          ["social-editor", "Social Links"],
          ["theme-editor", "Theme Editor"],
          ["messages-viewer", "Messages Viewer"],
        ].map(([id, label]) => <a key={id} href={`#${id}`}>{label}</a>)}
        <button onClick={() => logoutAdmin()}><LogOut size={17} /> Logout</button>
      </aside>
      <section className="admin-content">
        <div className="admin-topbar">
          <div>
            <p className="eyebrow">Live CMS</p>
            <h1>Website editing dashboard</h1>
          </div>
          <div className="admin-actions">
            {usingFallback ? <button className="secondary-button" onClick={seedDefaultContent} disabled={saving}>Publish default content</button> : null}
            <button className="secondary-button" onClick={downloadSingleFile} type="button"><Download size={17} /> Download sumitweb.html</button>
            <button className="primary-button" onClick={save} disabled={saving}><Save size={17} /> {saving ? "Saving..." : "Save all changes"}</button>
          </div>
        </div>

        <section className="editor-section" id="hero-editor">
          <h2>Hero Editor</h2>
          <div className="editor-grid two">
            <div>
              <TextField label="Hero title" value={draft.hero.title} onChange={(title) => setDraft({ ...draft, hero: { ...draft.hero, title } })} />
              <TextAreaField label="Hero subtitle" value={draft.hero.subtitle} onChange={(subtitle) => setDraft({ ...draft, hero: { ...draft.hero, subtitle } })} />
            </div>
            <ImagePicker label="Upload hero image" image={draft.hero.image} onImage={(image) => setDraft({ ...draft, hero: { ...draft.hero, image } })} />
          </div>
        </section>

        <section className="editor-section" id="services-editor">
          <div className="editor-heading"><h2>Services Editor</h2><button onClick={addService}><Plus size={15} /> Add service</button></div>
          {draft.services.map((service, index) => (
            <div className="editor-card" key={service.id}>
              <div className="editor-card-controls">
                <button type="button" onClick={() => reorderService(index, -1)} disabled={index === 0} aria-label="Move up"><ArrowUp size={15} /></button>
                <button type="button" onClick={() => reorderService(index, 1)} disabled={index === draft.services.length - 1} aria-label="Move down"><ArrowDown size={15} /></button>
                <button type="button" className="danger" onClick={() => removeService(service.id)} aria-label="Remove"><Trash2 size={15} /></button>
              </div>
              <ImagePicker label="Upload service image" image={service.image} onImage={(image) => updateService(service.id, (item) => ({ ...item, image }))} />
              <TextField label="Title" value={service.title} onChange={(title) => updateService(service.id, (item) => ({ ...item, title }))} />
              <TextField label="Summary" value={service.summary} onChange={(summary) => updateService(service.id, (item) => ({ ...item, summary }))} />
              <TextAreaField label="Learn More details" value={service.details} onChange={(details) => updateService(service.id, (item) => ({ ...item, details }))} />
            </div>
          ))}
        </section>

        <section className="editor-section" id="portfolio-editor">
          <div className="editor-heading"><h2>Portfolio Editor</h2><button onClick={addProject}><Plus size={15} /> Add project</button></div>
          {draft.portfolio.map((project, index) => (
            <div className="editor-card" key={project.id}>
              <div className="editor-card-controls">
                <button type="button" onClick={() => reorderProject(index, -1)} disabled={index === 0} aria-label="Move up"><ArrowUp size={15} /></button>
                <button type="button" onClick={() => reorderProject(index, 1)} disabled={index === draft.portfolio.length - 1} aria-label="Move down"><ArrowDown size={15} /></button>
                <button type="button" className="danger" onClick={() => removeProject(project.id)} aria-label="Remove"><Trash2 size={15} /></button>
              </div>
              <ImagePicker label="Upload project image" image={project.image} onImage={(image) => updateProject(project.id, (item) => ({ ...item, image }))} />
              <TextField label="Name" value={project.name} onChange={(name) => updateProject(project.id, (item) => ({ ...item, name }))} />
              <TextField label="Slug" value={project.slug} onChange={(slug) => updateProject(project.id, (item) => ({ ...item, slug }))} />
              <TextField label="Summary" value={project.summary} onChange={(summary) => updateProject(project.id, (item) => ({ ...item, summary }))} />
              <TextAreaField label="Description" value={project.description} onChange={(description) => updateProject(project.id, (item) => ({ ...item, description }))} />
              <TextField label="Tags separated by comma" value={project.tags.join(", ")} onChange={(tags) => updateProject(project.id, (item) => ({ ...item, tags: tags.split(",").map((tag) => tag.trim()).filter(Boolean) }))} />
            </div>
          ))}
        </section>

        <section className="editor-section" id="pricing-editor">
          <div className="editor-heading"><h2>Pricing Editor</h2><button onClick={addPlan}><Plus size={15} /> Add plan</button></div>
          {draft.pricing.map((plan, index) => (
            <div className="editor-card compact" key={plan.id}>
              <div className="editor-card-controls">
                <button type="button" onClick={() => reorderPlan(index, -1)} disabled={index === 0} aria-label="Move up"><ArrowUp size={15} /></button>
                <button type="button" onClick={() => reorderPlan(index, 1)} disabled={index === draft.pricing.length - 1} aria-label="Move down"><ArrowDown size={15} /></button>
                <button type="button" className="danger" onClick={() => removePlan(plan.id)} aria-label="Remove"><Trash2 size={15} /></button>
              </div>
              <TextField label="Plan name" value={plan.name} onChange={(name) => updatePlan(plan.id, (item) => ({ ...item, name }))} />
              <TextField label="Price" value={plan.price} onChange={(price) => updatePlan(plan.id, (item) => ({ ...item, price }))} />
              <TextAreaField label="Features, one per line" value={plan.features.join("\n")} onChange={(features) => updatePlan(plan.id, (item) => ({ ...item, features: features.split("\n").map((feature) => feature.trim()).filter(Boolean) }))} />
            </div>
          ))}
        </section>

        <section className="editor-section" id="custom-blocks-editor">
          <div className="editor-heading"><h2>Custom Sections</h2><button onClick={addBlock}><Plus size={15} /> Add section</button></div>
          {(draft.customBlocks ?? []).length === 0 ? <p>No custom sections yet. Add free-form content blocks that appear on the homepage.</p> : null}
          {(draft.customBlocks ?? []).map((block, index) => (
            <div className="editor-card" key={block.id}>
              <div className="editor-card-controls">
                <button type="button" onClick={() => reorderBlock(index, -1)} disabled={index === 0} aria-label="Move up"><ArrowUp size={15} /></button>
                <button type="button" onClick={() => reorderBlock(index, 1)} disabled={index === (draft.customBlocks ?? []).length - 1} aria-label="Move down"><ArrowDown size={15} /></button>
                <button type="button" className="danger" onClick={() => removeBlock(block.id)} aria-label="Remove"><Trash2 size={15} /></button>
              </div>
              <ImagePicker label="Optional image" image={block.image || defaultContent.hero.image} onImage={(image) => updateBlock(block.id, (item) => ({ ...item, image }))} />
              <TextField label="Section title" value={block.title} onChange={(title) => updateBlock(block.id, (item) => ({ ...item, title }))} />
              <TextAreaField label="Section text" value={block.text} onChange={(text) => updateBlock(block.id, (item) => ({ ...item, text }))} />
            </div>
          ))}
        </section>

        <section className="editor-section" id="contact-editor">
          <h2>Contact Info Editor</h2>
          <div className="editor-grid two">
            <TextField label="Phone" value={draft.contact.phone} onChange={(phone) => setDraft({ ...draft, contact: { ...draft.contact, phone } })} />
            <TextField label="Email" value={draft.contact.email} onChange={(email) => setDraft({ ...draft, contact: { ...draft.contact, email } })} />
            <TextField label="WhatsApp URL" value={draft.contact.whatsapp} onChange={(whatsapp) => setDraft({ ...draft, contact: { ...draft.contact, whatsapp } })} />
            <TextField label="Address" value={draft.contact.address} onChange={(address) => setDraft({ ...draft, contact: { ...draft.contact, address } })} />
          </div>
        </section>

        <section className="editor-section" id="social-editor">
          <h2>Social Links</h2>
          <p>Leave a field empty to hide that icon. Paste full https URLs.</p>
          <div className="editor-grid two">
            {(["facebook","instagram","twitter","linkedin","youtube","telegram"] as Array<keyof SocialLinks>).map((key) => (
              <TextField key={key} label={key.charAt(0).toUpperCase() + key.slice(1)} value={draft.contact.social?.[key] ?? ""} onChange={(value) => updateSocial(key, value)} />
            ))}
          </div>
        </section>

        <section className="editor-section" id="theme-editor">
          <h2><Palette size={20} /> Theme Editor</h2>
          <p>Live preview applies after saving.</p>
          <div className="editor-grid two">
            <label className="color-field"><span>Primary (navy)</span><input type="color" value={draft.theme?.primary ?? "#061a36"} onChange={(event) => updateTheme({ primary: event.target.value })} /><input type="text" value={draft.theme?.primary ?? ""} onChange={(event) => updateTheme({ primary: event.target.value })} /></label>
            <label className="color-field"><span>Accent (gold)</span><input type="color" value={draft.theme?.accent ?? "#d8ad58"} onChange={(event) => updateTheme({ accent: event.target.value })} /><input type="text" value={draft.theme?.accent ?? ""} onChange={(event) => updateTheme({ accent: event.target.value })} /></label>
            <label className="color-field"><span>Background</span><input type="color" value={draft.theme?.background ?? "#fbf8f0"} onChange={(event) => updateTheme({ background: event.target.value })} /><input type="text" value={draft.theme?.background ?? ""} onChange={(event) => updateTheme({ background: event.target.value })} /></label>
          </div>
        </section>

        <section className="editor-section" id="messages-viewer">
          <h2>Messages Viewer</h2>
          {messageError ? <p className="form-error">{messageError}</p> : null}
          <div className="messages-list">
            {messages.length ? messages.map((message) => (
              <article key={message.id}>
                <strong>{message.name}</strong>
                <span>{message.email} · {message.phone}</span>
                <p>{message.message}</p>
                <small>{message.createdAt}</small>
              </article>
            )) : <p>No messages yet.</p>}
          </div>
        </section>
      </section>
    </main>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/demo/:slug" component={DemoPage} />
      <Route path="/project/:slug" component={ProjectPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={base === "" ? undefined : base}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
