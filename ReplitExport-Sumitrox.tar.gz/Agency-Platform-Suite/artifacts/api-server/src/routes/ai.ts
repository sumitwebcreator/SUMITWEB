import { Router, type IRouter } from "express";
import { GoogleGenAI } from "@google/genai";

const router: IRouter = Router();

const baseUrl = process.env.AI_INTEGRATIONS_GEMINI_BASE_URL;
const apiKey = process.env.AI_INTEGRATIONS_GEMINI_API_KEY;

const ai = baseUrl && apiKey ? new GoogleGenAI({ apiKey, httpOptions: { apiVersion: "", baseUrl } }) : null;

router.post("/ai/ask", async (req, res) => {
  try {
    if (!ai) {
      res.status(503).json({ error: "AI service is not configured." });
      return;
    }
    const question = String(req.body?.question ?? "").trim();
    const context = String(req.body?.context ?? "").trim();
    if (!question) {
      res.status(400).json({ error: "Question is required." });
      return;
    }

    const systemPrompt = `You are SumitWebCreator's smart website assistant. SumitWebCreator is a professional web creation agency that builds premium agency websites, ecommerce stores, SEO foundations, and ongoing maintenance plans. Always answer in clear, friendly, business-ready language. Keep responses concise (max 5 sentences) unless the user asks for detail. If the user's question is unrelated to websites, business, design, marketing, or technology, still answer helpfully but stay professional. Never use emojis.\n\nLive website context (use only if relevant):\n${context}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        { role: "user", parts: [{ text: `${systemPrompt}\n\nUser question: ${question}` }] },
      ],
      config: { maxOutputTokens: 8192 },
    });

    const text = response.text ?? "";
    res.json({ answer: text || "I could not generate an answer right now. Please try again." });
  } catch (error) {
    res.status(500).json({ error: error instanceof Error ? error.message : "AI request failed." });
  }
});

export default router;
