# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Current Product

- **SumitWebCreator**: React + Vite web application at `artifacts/sumit-web-creator`, served from `/`.
- The app is a professional agency platform with public website pages, admin dashboard, Firebase real-time content editing, portfolio demo/detail routes, contact form storage, and a scoped AI assistant.
- Firebase is used from the client through `src/lib/firebase.ts` with shared `VITE_FIREBASE_*` environment variables and public fallback config for project `sumit-web-16cd2`.
- Firestore content path: collection `websiteContent`, document `main`.
- Firestore messages path: collection `messages`.
- Allowed admin emails (multi-admin, up to 5 sessions): `sumitwebcreators@gmail.com`, `sb888284@gmail.com`, `bhargavas382@gmail.com`. Passwords are verified by Firebase Authentication.
- Each admin must exist in Firebase Authentication with Email/Password before login will work.
- AI Assistant uses Gemini via `/api/ai/ask` (api-server), powered by `@google/genai` and Replit AI Integrations (gemini-2.5-flash).
- Admin features: Hero/Services/Portfolio/Pricing editors with reorder + remove, Custom Sections builder, Social Links (FB/IG/Twitter/LinkedIn/YouTube/Telegram), Theme Editor (primary/accent/background colors via CSS vars), Messages Viewer, and "Download sumitweb.html" single-file site export.
- Vite dev proxy forwards `/api` → `http://localhost:8080` so the website can call the api-server during development.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Web app**: React + Vite
- **Firebase client SDK**: Authentication + Firestore
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/sumit-web-creator run dev` — run SumitWebCreator locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
